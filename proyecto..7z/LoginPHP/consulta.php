<?php 
require 'conexion.php';
$query = mysqli_query($conexion,$catalogo);
$array = mysqli_fetch_array($query);
?>