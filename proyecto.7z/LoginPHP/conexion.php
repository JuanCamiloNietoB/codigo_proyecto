<?php
include("configuracion.php");
$conexion = mysqli_connect($server,$user,$pass,$bd);
if(mysqli_connect_errno()){
   echo "Error connecting to", mysqli_connect_error();
   exit();
}else{
echo "Connection established";
}
?>